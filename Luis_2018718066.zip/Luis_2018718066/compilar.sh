#!/bin/bash
python -m py_compile board_class.py